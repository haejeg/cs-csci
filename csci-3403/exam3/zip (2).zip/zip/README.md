# Notemaker data folder

This is where all of NoteMaker's important data lives. Please don't put non-production files in here.

If you want to access the database, you can use the command `sqlite3 database.sqlite3`.